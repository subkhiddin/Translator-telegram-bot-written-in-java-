package org.example;

public interface BotConstant {

}
