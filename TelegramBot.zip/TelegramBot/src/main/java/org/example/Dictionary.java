package org.example;

import org.json.JSONObject;

import javax.net.ssl.HttpsURLConnection;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Dictionary {
    private Map<Integer, Map<String, String>> examples = new HashMap<>();
    private String pronunciation;
    private String pos;

    public boolean isValid() {
        return _isValid;
    }

    public String getPronunciation() {
        return pronunciation;
    }

    public String getPos() {
        return pos;
    }

    private boolean _isValid = true;


    private ArrayList<String> result = new ArrayList<>();

    public ArrayList<String> getResult() {
        return result;
    }

    private ArrayList<String> synonyms = new ArrayList<>();

    public Map<Integer, Map<String, String>> getExamples() {
        return examples;
    }

    public ArrayList<String> getSynonyms() {
        return synonyms;
    }

    public void sendRequest(String word, String lang) throws IOException {
        try {
            URL url = new URL("https://dictionary.yandex.net/api/v1/dicservice.json/lookup?key=dict.1.1.20221114T111217Z.5b126bab68e62d3d.d885bc531d8eb3a2d5bb67f4574b122dedbc017d&lang=" + lang + "&text=" + word);
            HttpURLConnection urlConnection = (HttpsURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();
            int code = urlConnection.getResponseCode();
            if (code != 200) {
                System.out.println("HTTPResponseCode " + code);
            } else {
                ArrayList<String> _tempSyn = new ArrayList<>();
                Map<Integer, Map<String, String>> _tempEx = new HashMap<>();
                ArrayList<String> _tempRes = new ArrayList<>();


                StringBuilder stringBuilder = new StringBuilder();
                Scanner scanner = new Scanner(url.openStream());
                while (scanner.hasNext()) {
                    stringBuilder.append(scanner.nextLine());
                }

                System.out.println(stringBuilder.toString());
                JSONObject arr = new JSONObject(stringBuilder.toString());

                if (arr.getJSONArray("def").isEmpty()) {
                    _isValid = false;
                    return;
                }
                for (int j = 0; j < arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").length(); j++) {
                    if (!arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).isNull("syn")) {
//                    System.out.println("hey" + "-2");

                        for (int i = 0; i < arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).getJSONArray("syn").length(); i++) {
                            _tempSyn.add(arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).getJSONArray("syn").getJSONObject(i).getString("text"));
                        }
                    }
                    if (!arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).isNull("ex")) {
//                    System.out.println("hey" + "-1");
                        for (int i = 0; i < arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).getJSONArray("ex").length(); i++) {
                            Map<String, String> _temp = new HashMap<>();
                            _temp.put("text", arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).getJSONArray("ex").getJSONObject(i).getString("text"));
                            _temp.put("tr", arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).getJSONArray("ex").getJSONObject(i).getJSONArray("tr").getJSONObject(0).getString("text"));
                            _tempEx.put(i, _temp);
                        }
                    }
                    if (!arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).isNull("text")) {
                        _tempRes.add(arr.getJSONArray("def").getJSONObject(0).getJSONArray("tr").getJSONObject(j).getString("text"));
                    }
                    if (!arr.getJSONArray("def").getJSONObject(0).isNull("ts")) {
//                    System.out.println("hey" + 0);
                        pronunciation = arr.getJSONArray("def").getJSONObject(0).getString("ts");
                    }
                    if (!arr.getJSONArray("def").getJSONObject(0).isNull("pos")) {
//                    System.out.println("hey" + 1);
                        pos = arr.getJSONArray("def").getJSONObject(0).getString("pos");
                    }
                }
                synonyms = _tempSyn;
                examples = _tempEx;
                result = _tempRes;
                System.out.println(result);
                // System.out.println(synonyms);
                // System.out.println(examples);
                // System.out.println(pronunciation);
                // System.out.println(pos);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


}

