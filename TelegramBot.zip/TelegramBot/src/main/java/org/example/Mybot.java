package org.example;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
// import InlinKeyboardMarkup
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.*;
//
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import java.io.IOException;
import java.util.ArrayList;
//  InlineKeyboardButton of telegram
//import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.EditMessageReplyMarkup;

// list class
import java.util.*;

    
public class Mybot extends TelegramLongPollingBot {
    private String lang_from = "en";
    private String lang_to = "en";
    final String[] langs = {"en","kz","ru","tr","de","fr","pl","es","it"};
    final public HashMap<String,String> language_to_flag = new HashMap<String,String>() {{
        put("uz" , "🇺🇿");
        put("ru" , "🇷🇺");
        put("kz" , "🇰🇿");
        put("tr" , "🇹🇷");
        put("en" , "🏴󠁧󠁢󠁥󠁮󠁧󠁿");
        put("de" , "🇩🇪");
        put("fr" , "🇫🇷");
        put("pl" , "🇵🇹");
        put("es" , "🇪🇸");
        put("it" , "🇮🇹");
    }};

    @Override
    public String getBotUsername() {

        // Ftranslator name --- 
        //return "ftranslatorbot";
        // https://t.me/SimpleTranslatorrbot --- Simple Translator
        return "SimpleTranslatorrbot";
    }
    @Override
    public String getBotToken() {

        // Ftranslators token --- 
        //return "5767353885:AAE2crX0zFgtdA1Gqgcnt38xiT40J3RpM1s";
        // https://t.me/SimpleTranslatorrbot --- Simple Translator
        return "5598487537:AAGJoZniGDhQ2qreMXiXR6G90nsK_fSktqE";
    }

    public String get_current_lenguage(String cur, String exp)
    {
        return cur.equals(exp) ? exp + "📌" : exp;
    }


    public void handleCallback(CallbackQuery cl, String chatId) throws TelegramApiException{
        Message message = cl.getMessage();
        String[] params = cl.getData().split(":");
        String lang = params[1];
        switch(params[0])
        {
            case "FROM":
            lang_from = lang;
                EditMessageReplyMarkup ed = new EditMessageReplyMarkup();
                ed.setChatId(chatId);
                ed.setMessageId(message.getMessageId());
                List<List<InlineKeyboardButton>> buttons = new ArrayList<>();
                for (String l : langs) {
                    List<InlineKeyboardButton> row = new ArrayList<>();
                    InlineKeyboardButton button = new InlineKeyboardButton();
                    InlineKeyboardButton button_2 = new InlineKeyboardButton();

                    button.setText(language_to_flag.get(l) + get_current_lenguage(lang_from, l));
                    button.setCallbackData("FROM:" + l);
                    button_2.setText(language_to_flag.get(l) + get_current_lenguage(lang_to, l));
                    button_2.setCallbackData("TO:" + l);
                    row.add(button);
                    row.add(button_2);
                    buttons.add(row);
                }
                InlineKeyboardMarkup ikm = new InlineKeyboardMarkup();
                ikm.setKeyboard(buttons);
                ed.setReplyMarkup(ikm);
                execute(ed);
            break;
            case "TO":
                lang_to = lang;
                ed = new EditMessageReplyMarkup();
                ed.setChatId(chatId);
                ed.setMessageId(message.getMessageId());
                buttons = new ArrayList<>();
                for (String l : langs) {
                    List<InlineKeyboardButton> row = new ArrayList<>();
                    InlineKeyboardButton button = new InlineKeyboardButton();
                    InlineKeyboardButton button_2 = new InlineKeyboardButton();

                    button.setText(language_to_flag.get(l) + get_current_lenguage(lang_from, l));
                    button.setCallbackData("FROM:" + l);
                    button_2.setText(language_to_flag.get(l) + get_current_lenguage(lang_to, l));
                    button_2.setCallbackData("TO:" + l);
                    row.add(button);
                    row.add(button_2);
                    buttons.add(row);
                }
                ikm = new InlineKeyboardMarkup();
                ikm.setKeyboard(buttons);
                ed.setReplyMarkup(ikm);
                execute(ed);
            break;
        }
    }
    public void lang_command(String chatId)
    {
        System.out.println("/LANG COMMAND");
        List<List<InlineKeyboardButton>> buttons = new ArrayList<>();
        for (String lang : langs) {
            List<InlineKeyboardButton> row = new ArrayList<>();
            InlineKeyboardButton button = new InlineKeyboardButton();
            InlineKeyboardButton button_2 = new InlineKeyboardButton();

            button.setText(language_to_flag.get(lang) +  get_current_lenguage(lang_from, lang));
            button.setCallbackData("FROM:" + lang);
            button_2.setText(language_to_flag.get(lang) + get_current_lenguage(lang_to, lang));
            button_2.setCallbackData("TO:" + lang);
            row.add(button);
            row.add(button_2);
            buttons.add(row);
        }
        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        markup.setKeyboard(buttons);
        try {
            execute(SendMessage.builder().chatId(chatId).text("Please choose language").replyMarkup(markup).build());
        } catch (TelegramApiException e) {
            throw new RuntimeException(e);
        }
    }
    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasCallbackQuery())
        {
            String chatId = update.getCallbackQuery().getMessage().getChatId().toString();
            CallbackQuery cl = update.getCallbackQuery();
            try {
                handleCallback(cl, chatId);
            } catch (TelegramApiException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }


        else if (update.hasMessage()) {
            Dictionary d = new Dictionary();
            String chatId = update.getMessage().getChatId().toString();
            Message message = update.getMessage();

            
            if (message.hasText()) {
                String text = message.getText();
                String text_2 = message.getText();
                // text start with /start then send welcome message
                // text start with /help then send help message
                // text start with /translate then send translate message
                // note /translate should have words after it like /translate hello where hello is the word going to be translated
                    if (text.contains("/start")) {
                        SendMessage sendMessage = new SendMessage();
                        sendMessage.setText("Welcome to our translator bot!\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n" +
                                "################" + "\n"
                        );
                        sendMessage.setChatId(chatId);
                        try {
                            execute(sendMessage);
                        } catch (TelegramApiException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    // else if (text.contains("/translate") ) {
                        
                    //     ArrayList<String> result = new ArrayList<>();
                    //     String[] words = text.split(" ");
                    //     // print all word in words
                    //     for (String word : words) {
                    //         System.out.println(word);
                    //     }
                    //     String word = words[1];
                    //     // String lang = words[2];
                    //     SendMessage sendMessage = new SendMessage();
                    //     sendMessage.setText("Just a second please!");
                    //     sendMessage.setChatId(chatId);
                    //     try {
                    //         execute(sendMessage);
                    //     } catch (TelegramApiException e) {
                    //         throw new RuntimeException(e);
                    //     }
                    //     try {
                    //         d.sendRequest(word, lang_from+"-"+lang_to);
                    //         result = d.getResult();
                    //         // print result of translation
                    //         for (String s : result) {
                    //             System.out.println(s);
                    //         }
                    //         String othertranslation = "";
                    //         for (int i = 1; i < result.size(); i++) {
                    //             String s = Integer.toString(i);
                    //             if (i == 1)
                    //                 othertranslation += "\t";
                    //             othertranslation += s + ". " + result.get(i) + "\n" + "\t";
                    //         }
                    //         String synonyms = "\n\t";
                    //         for (int i = 0; i < d.getSynonyms().size(); i++ )
                    //         {
                    //             //convert int to   string
                    //             String s = Integer.toString(i+1);
                    //             synonyms += s + ". " + d.getSynonyms().get(i) + '\n' + "\t" + '\t' + '\t';
                    //         }
                    //         sendMessage.setText("Word: " + word + "\n" +
                    //                 "Translation: " + result.get(0) + "\n" +
                    //                 "other translations: "  + "\n" + othertranslation + "\n" +
                    //                 "Part of speech: " + d.getPos() + "\n" +
                    //                 "Pronunciation: " + d.getPronunciation() + "\n" +
                    //                 "Synonyms: " + synonyms + "\n"
                    //         );
                    //         try {
                    //             execute(sendMessage);
                    //         } catch (TelegramApiException e) {
                    //             throw new RuntimeException(e);
                    //         }

                    //         System.out.println(d.isValid());
                    //     } catch (IOException e) {
                    //         e.printStackTrace();
                    //         System.out.println("Hey unsupported word");
                    //     }
                    // }
                    else if (text.contains("/help")) {
                        SendMessage sendMessage = new SendMessage();
                        sendMessage.setText("This is help message");
                        sendMessage.setChatId(chatId);
                        try {
                            execute(sendMessage);
                        } catch (TelegramApiException e) {
                            throw new RuntimeException(e);
                        }
                        String t = "There are four commands You can use with this bot" + "\n"+
                        "/start " + "- to give a start to the bot 🏎🏎🏎" + "\n" +
                        "/help" + "- to get this message 👆👇" + "\n" +
                        "/language"+ "- to change language settings" + "\n" +
                        "from language to language" + "\n" + "\n" +
                        "just type any word that is need to be translated" + ""  ;
                        sendMessage.setText(t);
                        sendMessage.setChatId(chatId);
                        try {
                            execute(sendMessage);
                        } catch (TelegramApiException e) {
                            throw new RuntimeException(e);
                        }
                    }
                    else if (text.contains("/language"))
                    {
                        lang_command(chatId);
                    }
                    else
                    {   
                        System.out.println("TRANSLATING");
                        ArrayList<String> result = new ArrayList<>();
                        String[] words = text.split(" ");
                        // print all word in words
                        for (String word : words) {
                            System.out.println(word);
                        }
                        String word = words[0];
                        // String lang = words[2];
                        SendMessage sendMessage = new SendMessage();
                        sendMessage.setText("Just a second please!");
                        sendMessage.setChatId(chatId);
                        try {
                            execute(sendMessage);
                        } catch (TelegramApiException e) {
                            throw new RuntimeException(e);
                        }
                        try {
                            d.sendRequest(word, lang_from+"-"+lang_to);
                            result = d.getResult();
                            // print result of translation
                            for (String s : result) {
                                System.out.println(s);
                            }
                            String othertranslation = "";
                            for (int i = 1; i < result.size(); i++) {
                                String s = Integer.toString(i);
                                if (i == 1)
                                    othertranslation += "\t";
                                othertranslation += s + ". " + result.get(i) + "\n" + "\t";
                            }
                            String synonyms = "\n\t";
                            for (int i = 0; i < d.getSynonyms().size(); i++ )
                            {
                                //convert int to   string
                                String s = Integer.toString(i+1);
                                synonyms += s + ". " + d.getSynonyms().get(i) + '\n' + "\t" + '\t' + '\t';
                            }
                            sendMessage.setText("Word: " + word + "\n" +
                                    "Translation: " + result.get(0) + "\n" +
                                    "other translations: "  + "\n" + othertranslation + "\n" +
                                    "Part of speech: " + d.getPos() + "\n" +
                                    "Pronunciation: " + d.getPronunciation() + "\n" +
                                    "Synonyms: " + synonyms + "\n"
                            );
                            try {
                                execute(sendMessage);
                            } catch (TelegramApiException e) {
                                throw new RuntimeException(e);
                            }

                            System.out.println(d.isValid());
                        } catch (IOException e) {
                            e.printStackTrace();
                            System.out.println("Hey unsupported word");
                        }
                    }   
            }
        }
    }
}
